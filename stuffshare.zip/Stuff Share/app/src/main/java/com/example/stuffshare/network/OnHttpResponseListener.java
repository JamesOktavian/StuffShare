package com.example.stuffshare.network;

public interface OnHttpResponseListener {

    public abstract void OnHttpResponse(String result);
}
