package com.example.stuffshare.network;

/**
 * Created by phephen 2019
 */

public interface OnGetDataFinish {

    public abstract void OnGetDataComplete();
}
