package com.example.stuffshare.network;

import android.os.AsyncTask;

import java.io.ByteArrayOutputStream;

public class UploadFilesTask extends AsyncTask<Object, Void, String> {

    OnHttpResponseListener onHttpResponseListener;

    public void setOnHttpResponseListener(OnHttpResponseListener listener) {
        onHttpResponseListener = listener;
    }

    @Override
    protected String doInBackground(Object... params) {
        String url = (String) params[0];
        String userid = (String) params[1];
        String organization = (String) params[2];
        String address = (String) params[3];
        String akta = (String) params[4];
        String penganggung_jawab = (String) params[5];
        String npwp = (String) params[6];
        ByteArrayOutputStream aktaBoas = new ByteArrayOutputStream();
        ByteArrayOutputStream npwpBoas = new ByteArrayOutputStream();
        ByteArrayOutputStream organizationBoas = new ByteArrayOutputStream();
        String data = "";

        try {
            HttpMultipartClient client = new HttpMultipartClient(url);
            client.connectForMultipart();
            client.addFormPart("userid", userid);
            client.addFormPart("organization", organization);
            client.addFormPart("address", address);
            client.addFormPart("akta", akta);
            client.addFormPart("penganggungjawab", penganggung_jawab);
            client.addFormPart("npwp", npwp);
            client.addFilePart("img_akta", "png", aktaBoas.toByteArray());
            client.addFilePart("img_npwp", "png", npwpBoas.toByteArray());
            client.addFilePart("img_organization", "png", organizationBoas.toByteArray());
            client.finishMultipart();
            data = client.getResponse();
        } catch (Throwable throwable){
            throwable.printStackTrace();
        }
        return data;
    }

    @Override
    protected void onPostExecute(String result) {
        if (onHttpResponseListener != null){
            onHttpResponseListener.OnHttpResponse(result);
        }
    }
}
