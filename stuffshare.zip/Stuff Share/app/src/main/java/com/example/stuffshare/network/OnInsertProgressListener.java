package com.example.stuffshare.network;

/**
 * Created by phephen 2019
 */

public interface OnInsertProgressListener {
    public abstract void OnInsertProgress(int progress, int count);
}
