package com.example.stuffshare.model;

public class Item {

    int image;

    public Item(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
