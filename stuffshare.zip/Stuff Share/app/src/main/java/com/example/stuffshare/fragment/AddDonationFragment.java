package com.example.stuffshare.fragment;

import androidx.fragment.app.Fragment;

public class AddDonationFragment extends Fragment {

}
