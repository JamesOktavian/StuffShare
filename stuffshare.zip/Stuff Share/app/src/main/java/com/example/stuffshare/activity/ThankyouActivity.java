package com.example.stuffshare.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.stuffshare.MainActivity;
import com.example.stuffshare.R;
import com.example.stuffshare.StuffShareApp;
import com.example.stuffshare.util.AppUtils;
import com.example.stuffshare.util.SharedPrefManager;

public class ThankyouActivity extends AppCompatActivity {

    TextView thankyouTitle, sendDonation, addressSent, transferDonation, noRekDonation, quote;
    Button backButton;
    StuffShareApp stuffShareApp;
    SharedPrefManager sharedPrefManager;
    AppUtils appUtils;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thankyou_activity);

        stuffShareApp = (StuffShareApp) getApplication();
        sharedPrefManager = new SharedPrefManager(this);
        appUtils = new AppUtils();

        thankyouTitle = (TextView) findViewById(R.id.txtThankyouTitle);
        sendDonation = (TextView) findViewById(R.id.txtSendDonation);
        addressSent = (TextView) findViewById(R.id.txtAddressSent);
        transferDonation = (TextView) findViewById(R.id.txtTransferDonation);
        noRekDonation = (TextView) findViewById(R.id.txtNorekDonation);
        quote = (TextView) findViewById(R.id.txtQuote);

        thankyouTitle.setText(R.string.txt_thanks_donasi);
        sendDonation.setText(R.string.txt_sent_donasi);
        addressSent.setText(stuffShareApp.getCampaigner().getAlamatPenyelenggara());
        quote.setText(R.string.txt_quote);


        backButton = (Button) findViewById(R.id.btnBack);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goMainActivity = new Intent(ThankyouActivity.this, MainActivity.class);
                startActivity(goMainActivity);
                finish();
            }
        });
    }
}
