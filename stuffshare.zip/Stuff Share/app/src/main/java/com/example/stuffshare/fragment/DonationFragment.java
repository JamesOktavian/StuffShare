package com.example.stuffshare.fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.stuffshare.R;
import com.example.stuffshare.StuffShareApp;
import com.example.stuffshare.activity.CollectDonationActivity;
import com.example.stuffshare.adapter.ListDonationAdapter;
import com.example.stuffshare.model.Campaigner;
import com.example.stuffshare.model.RowItem;
import com.example.stuffshare.util.AppUtils;

import java.util.ArrayList;
import java.util.List;

import es.dmoral.toasty.Toasty;

/**
 * created by niko and team
 */
public class DonationFragment extends Fragment {

    StuffShareApp stuffShareApp;;

    ListView listView;
    List<RowItem> rowItemList;
    ArrayList<Campaigner> arrayList = null;
    ListDonationAdapter listDonationAdapter = null;
    SwipeRefreshLayout swipeRefreshLayout = null;
    ProgressBar progressBar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_donation, container, false);
        stuffShareApp = (StuffShareApp) getActivity().getApplication();

        TextView toolbar_title = view.findViewById(R.id.toolbar_title);
        toolbar_title.setText(R.string.txt_donasi_title);
        toolbar_title.setTextColor(getResources().getColor(R.color.textColorToolbar));
        toolbar_title.setTextSize(30);

        progressBar = view.findViewById(R.id.progressBar);
        swipeRefreshLayout = view.findViewById(R.id.swiperefresh);

        listView = (ListView) view.findViewById(R.id.itemListView);
        arrayList = new ArrayList<Campaigner>();
        listDonationAdapter = new ListDonationAdapter(getContext(), R.layout.list_view_donation, arrayList);
        listView.setAdapter(listDonationAdapter);

        if (listDonationAdapter != null) {
            progressBar.setVisibility(View.GONE);
        }

        getDataCampaign("", listDonationAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Campaigner rowItem = (Campaigner) arrayList.get(position);
                String massDonasi = rowItem.getMasaDonasi();
                int waktuDonasi = Integer.parseInt(massDonasi);
                if (waktuDonasi <= 0){
                    view.setEnabled(false);
                    Toasty.info(getActivity(), "Masa donasi sudah habis", Toasty.LENGTH_SHORT, true).show();
                } else {
                    stuffShareApp.setSelectedCampaigner(rowItem);
                    Intent goIntent = new Intent(getActivity(), CollectDonationActivity.class);
                    goIntent.putExtra("IMAGE_NAME", rowItem.getImageCampaign());
                    stuffShareApp.setImgCampaign(rowItem.getImageCampaign());
                    startActivity(goIntent);
                }
            }
        });

        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView absListView, int i) {

            }

            @Override
            public void onScroll(AbsListView absListView, int i, int i1, int i2) {
                if (listView.getChildAt(0) != null) {
                    swipeRefreshLayout.setEnabled(listView.getFirstVisiblePosition() == 0 &&
                            listView.getChildAt(0).getTop() == 0);
                }
            }
        });

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getDataCampaign("", listDonationAdapter);
            }
        });


        return view;
    }

    public void getDataCampaign (String data, final ListDonationAdapter adapter){
        final AppUtils appUtils = new AppUtils();
        appUtils.getDataCampaign(getContext(), stuffShareApp, arrayList, adapter);
        appUtils.setOnGetDataFinish(() -> {
            swipeRefreshLayout.setRefreshing(false);
        });
    }
}
