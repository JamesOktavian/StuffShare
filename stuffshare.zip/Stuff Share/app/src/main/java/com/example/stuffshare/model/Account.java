package com.example.stuffshare.model;

public class Account {
    private String menu;

    public Account(String menu) {
        this.menu = menu;
    }

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }
}
