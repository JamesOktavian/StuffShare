package com.example.stuffshare.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;
import com.example.stuffshare.R;
import com.example.stuffshare.StuffShareApp;
import com.example.stuffshare.model.CategoryBarang;

import java.util.ArrayList;

public class CollectDonationAdapter extends ArrayAdapter<CategoryBarang> {

    Context context;
    StuffShareApp stuffShareApp;

    public CollectDonationAdapter(Context context, int textViewResourceId, ArrayList<CategoryBarang> categoryBarangs){
        super(context, textViewResourceId, categoryBarangs);
        this.context = context;
        stuffShareApp = (StuffShareApp) this.context.getApplicationContext();
    }

    private class ViewHolder {
        ImageView imageView;
        TextView txtTitleBarang;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder = null;
        CategoryBarang campaigner = getItem(position);
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.list_view_collect_donation_activity, null);
            holder = new ViewHolder();
            holder.imageView = (ImageView) convertView.findViewById(R.id.listview_image);
            holder.txtTitleBarang = (TextView) convertView.findViewById(R.id.listview_item_title);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Picasso.with(context).load(campaigner.getImageId()).into(holder.imageView);
        int jmlCampaign = Integer.parseInt(campaigner.getCount());
        if (jmlCampaign != 0) {
            holder.txtTitleBarang.setText(campaigner.getProductName() + " " +
                    jmlCampaign);
        } else {
            holder.txtTitleBarang.setVisibility(View.GONE);
            holder.imageView.setVisibility(View.GONE);
        }


        return convertView;
    }
}
