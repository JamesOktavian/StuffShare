package com.example.stuffshare.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.stuffshare.R;

public class ThankyouConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thankyou_confirmation);
    }
}