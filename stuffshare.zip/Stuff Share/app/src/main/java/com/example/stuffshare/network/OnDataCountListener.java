package com.example.stuffshare.network;

/**
 * Created by phephen 2019
 */

public interface OnDataCountListener {
    public abstract void OnDataCount(int count);
}
