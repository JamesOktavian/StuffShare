package com.example.stuffshare.model;

public class Data {

    String iduser;
    String tglBuat;
    String tglSelesai;
    int masaDonasi;

    public String getIduser() {
        return iduser;
    }

    public void setIduser(String iduser) {
        this.iduser = iduser;
    }

    public String getTglBuat() {
        return tglBuat;
    }

    public void setTglBuat(String tglBuat) {
        this.tglBuat = tglBuat;
    }

    public String getTglSelesai() {
        return tglSelesai;
    }

    public void setTglSelesai(String tglSelesai) {
        this.tglSelesai = tglSelesai;
    }

    public int getMasaDonasi() {
        return masaDonasi;
    }

    public void setMasaDonasi(int masaDonasi) {
        this.masaDonasi = masaDonasi;
    }
}
