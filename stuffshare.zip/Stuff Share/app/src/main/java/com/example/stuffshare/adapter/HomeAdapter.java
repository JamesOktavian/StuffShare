package com.example.stuffshare.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.example.stuffshare.R;
import com.example.stuffshare.StuffShareApp;
import com.example.stuffshare.activity.AlertHaveCampaignActivity;
import com.example.stuffshare.activity.AlertQuestionActivity;
import com.example.stuffshare.activity.SubmissionActivity;
import com.example.stuffshare.fragment.AccountPlusFragment;
import com.example.stuffshare.fragment.DonationFragment;
import com.example.stuffshare.fragment.InformationItemDonationFragment;
import com.example.stuffshare.fragment.MyDonationFragment;
import com.example.stuffshare.fragment.ScheduleDonationFragment;
import com.example.stuffshare.model.Item;
import com.example.stuffshare.util.SharedPrefManager;

import org.json.JSONObject;

import java.util.ArrayList;

import es.dmoral.toasty.Toasty;

import static com.example.stuffshare.MainActivity.ShowFragment;

public class HomeAdapter extends ArrayAdapter {

    Context context;
    ArrayList <Item>homeItems = new ArrayList<>();
    StuffShareApp stuffShareApp;
    JSONObject jObj, resObj;
    SharedPrefManager sharedPrefManager;
    String masaDonasi;


    public HomeAdapter(Context context, int textViewResourceId, ArrayList <Item>value){
        super(context, textViewResourceId, value);
        this.homeItems = value;
        this.context = context;
        stuffShareApp = (StuffShareApp) this.context.getApplicationContext();
        sharedPrefManager = new SharedPrefManager(getContext());
    }

    @Override
    public int getCount() {
        return super.getCount();
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if (v == null){
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.grid_view_items, null);
//            TextView textView = (TextView) v.findViewById(R.id.textView);
            ImageView imageView = (ImageView) v.findViewById(R.id.iVHome);
            imageView.setImageResource(homeItems.get(position).getImage());
//            imageView.setForegroundGravity(Gravity.CENTER);
//            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
//            imageView.getAdjustViewBounds();
//            imageView.getLayoutParams().width = 800;
            imageView.getLayoutParams().height = 400;

        }
        int type = position/1;
        switch (type){
            case 0:
//                v.setBackgroundResource(R.drawable.ikon_donasi);
                v.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DonationFragment donationFragment = new DonationFragment();
                        Activity activity = (Activity) context;
                        FragmentManager fragmentManager = ((FragmentActivity) getContext()).getSupportFragmentManager();
                        ShowFragment(R.id.fl_container, donationFragment, fragmentManager);
                    }
                });
                break;
            case 1:
//                v.setBackgroundResource(R.drawable.add_donation_rounded);
                v.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (stuffShareApp.getData() == null){
                            Intent goAlertQuestionActivity = new Intent(getContext(), AlertQuestionActivity.class);
                            context.startActivity(goAlertQuestionActivity);
                        } else {
                            if (!stuffShareApp.getData().getIduser().isEmpty()){
                                Log.i(stuffShareApp.TAG, "user 1 " + stuffShareApp.getData().getIduser());
                                Log.i(stuffShareApp.TAG, "user 2 " + sharedPrefManager.getSPUserid());
                                Log.i(stuffShareApp.TAG, "masa donasi " + stuffShareApp.getData().getMasaDonasi());
                                if (stuffShareApp.getData().getIduser().equals(sharedPrefManager.getSPUserid()) && stuffShareApp.getData().getMasaDonasi() > 0){
                                    Intent goAlertHaveCampaignActivity = new Intent(getContext(), AlertHaveCampaignActivity.class);
                                    context.startActivity(goAlertHaveCampaignActivity);
                                } else {
                                    Intent goAlertQuestionActivity = new Intent(getContext(), AlertQuestionActivity.class);
                                    context.startActivity(goAlertQuestionActivity);
                                }
                            } else {
                                Intent goAlertQuestionActivity = new Intent(getContext(), AlertQuestionActivity.class);
                                context.startActivity(goAlertQuestionActivity);
                            }
                        }
                    }
                });
                break;
            case 2:
//                v.setBackgroundResource(R.drawable.account_plus_rounded);
                v.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (sharedPrefManager.getSPAkunplus() == 1){
                            Toasty.info(getContext(), "anda sudah terdaftar sebagai akun plus tidak perlu daftar lagi",
                                    Toasty.LENGTH_SHORT, true).show();
                        } else {
                            AccountPlusFragment accountPlusFragment = new AccountPlusFragment();
                            Activity activity = (Activity) context;
                            FragmentManager fragmentManager = ((FragmentActivity) getContext()).getSupportFragmentManager();
                            ShowFragment(R.id.fl_container, accountPlusFragment, fragmentManager);
                        }
                    }
                });
                break;
            case 3:
//                v.setBackgroundResource(R.drawable.schedule_donation_rounded);
                v.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ScheduleDonationFragment scheduleDonationFragment = new ScheduleDonationFragment();
                        Activity activity = (Activity) context;
                        FragmentManager fragmentManager = ((FragmentActivity) getContext()).getSupportFragmentManager();
                        ShowFragment(R.id.fl_container, scheduleDonationFragment, fragmentManager);
                    }
                });
                break;
            case 4:
//                v.setBackgroundResource(R.drawable.information_donation_rounded);
                v.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        InformationItemDonationFragment informationItemDonationFragment = new InformationItemDonationFragment();
                        Activity activity = (Activity) context;
                        FragmentManager fragmentManager = ((FragmentActivity) getContext()).getSupportFragmentManager();
                        ShowFragment(R.id.fl_container, informationItemDonationFragment, fragmentManager);
                    }
                });
                break;
            case 5:
//                v.setBackgroundResource(R.drawable.status_donation_rounded);
                v.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        MyDonationFragment myDonationFragment = new MyDonationFragment();
                        Activity activity = (Activity) context;
                        FragmentManager fragmentManager = ((FragmentActivity) getContext()).getSupportFragmentManager();
                        ShowFragment(R.id.fl_container, myDonationFragment, fragmentManager);
                    }
                });
                break;
        }
        return v;
    }

    public void dialog() {
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
        alertDialog.setView(R.layout.alert_dialog_layout);
//        alertDialog.setTitle("Untuk mengajukan penggalangan donasi anda harus terdaftar di akun plus");
        alertDialog.setPositiveButton("Sudah",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent goSubmissionActivity = new Intent(getContext(), SubmissionActivity.class);
                        context.startActivity(goSubmissionActivity);
                    }
                });
        alertDialog.setNegativeButton("Belum, Daftar sekarang",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        AccountPlusFragment accountPlusFragment = new AccountPlusFragment();
                        Activity activity = (Activity) context;
                        FragmentManager fragmentManager = ((FragmentActivity) getContext()).getSupportFragmentManager();
                        ShowFragment(R.id.fl_container, accountPlusFragment, fragmentManager);
                    }
                });
        alertDialog.show();

        return;
    }
}
