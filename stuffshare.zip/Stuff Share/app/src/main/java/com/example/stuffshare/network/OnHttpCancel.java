package com.example.stuffshare.network;

public interface OnHttpCancel {

    public abstract void OnHttpCancel();
}
